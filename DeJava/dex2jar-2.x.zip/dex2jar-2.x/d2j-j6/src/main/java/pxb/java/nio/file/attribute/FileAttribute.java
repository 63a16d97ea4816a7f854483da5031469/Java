package pxb.java.nio.file.attribute;

public interface FileAttribute<T> {
}
